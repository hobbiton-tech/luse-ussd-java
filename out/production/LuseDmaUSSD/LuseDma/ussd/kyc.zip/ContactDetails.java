/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bumi.ussd.pojos.kyc;

/**
 *
 * @author Chisha
 */
public class ContactDetails
{
    private String alternate_number;

    private String province;

    private String physical_address3;

    private String physical_address2;

    private String postal_address1;

    private String physical_address1;

    private String postal_address2;

    private String postal_address3;

    private String email;

    public String getAlternateNumber ()
    {
        return alternate_number;
    }

    public void setAlternateNumber (String alternate_number)
    {
        this.alternate_number = alternate_number;
    }

    public String getProvince ()
    {
        return province;
    }

    public void setProvince (String province)
    {
        this.province = province;
    }

    public String getPhysicalAddress3 ()
    {
        return physical_address3;
    }

    public void setPhysicalAddress3 (String physical_address3)
    {
        this.physical_address3 = physical_address3;
    }

    public String getPhysicalAddress2 ()
    {
        return physical_address2;
    }

    public void setPhysicalAddress2 (String physical_address2)
    {
        this.physical_address2 = physical_address2;
    }

    public String getPostalAddress1 ()
    {
        return postal_address1;
    }

    public void setPostalAddress1 (String postal_address1)
    {
        this.postal_address1 = postal_address1;
    }

    public String getPhysicalAddress1 ()
    {
        return physical_address1;
    }

    public void setPhysicalAddress1 (String physical_address1)
    {
        this.physical_address1 = physical_address1;
    }

    public String getPostalAddress2 ()
    {
        return postal_address2;
    }

    public void setPostalAddress2 (String postal_address2)
    {
        this.postal_address2 = postal_address2;
    }

    public String getPostalAddress3 ()
    {
        return postal_address3;
    }

    public void setPostalAddress3 (String postal_address3)
    {
        this.postal_address3 = postal_address3;
    }

    public String getEmail ()
    {
        return email;
    }

    public void setEmail (String email)
    {
        this.email = email;
    }
}
			
